import { useEffect, useState } from 'react'
import { usePortfolio, sendMessage } from '../files/src/lib/usePortfolio'
import './portfolio.css'

const LINKS = [['about', 'About'], ['skills', 'Skills'], ['projects', 'Projects'], ['certifications', 'Certificates'], ['blogs', 'Blog'], ['contact', 'Contact']]

export default function Portfolio() {
  const d = usePortfolio()
  const [menu, setMenu] = useState(false)
  const [sent, setSent] = useState('')
  const s = d.settings || {}

  useEffect(() => {
    if (d.loading) return
    if (s.seo_title) document.title = s.seo_title
    let m = document.querySelector('meta[name=description]')
    if (!m) { m = document.createElement('meta'); m.name = 'description'; document.head.appendChild(m) }
    m.content = s.seo_description || ''
    if (s.primary_color) document.documentElement.style.setProperty('--accent', s.primary_color)
  }, [d.loading, s])

  if (d.loading) return <div className="boot" />

  const groups = d.skills.reduce((a, k) => ((a[k.category] ||= []).push(k), a), {})
  const submit = async (e) => {
    e.preventDefault()
    const f = Object.fromEntries(new FormData(e.target))
    const { error } = await sendMessage(f)
    setSent(error ? 'Message nahi gaya, dobara try karo.' : 'Message bhej diya. Jaldi reply milega.')
    if (!error) e.target.reset()
  }

  return (
    <>
      <header className="nav">
        <a href="#top" className="logo">{s.name}</a>
        <button className="menu" onClick={() => setMenu(!menu)} aria-label="Menu">{menu ? '✕' : '☰'}</button>
        <nav className={menu ? 'open' : ''}>
          {LINKS.map(([id, l]) => <a key={id} href={`#${id}`} onClick={() => setMenu(false)}>{l}</a>)}
        </nav>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-text">
            <p className="hi r1">Hi, main</p>
            <h1 className="r2">{s.name}</h1>
            <p className="tag r3">{s.tagline}</p>
            <div className="cta r4">
              <a className="btn" href="#projects">Mera kaam dekho</a>
              {s.resume_url && <a className="btn ghost" href={s.resume_url} target="_blank" rel="noreferrer">Resume</a>}
            </div>
          </div>
          {s.photo_url && <img className="photo r3" src={s.photo_url} alt={s.name} />}
        </section>

        <section id="about" className="sec"><h2>About</h2><p className="lead">{s.bio}</p></section>

        {d.skills.length > 0 && (
          <section id="skills" className="sec"><h2>Skills & Tools</h2>
            <div className="skillgrid">
              {Object.entries(groups).map(([cat, list]) => (
                <div className="panel" key={cat}><h3>{cat}</h3>
                  {list.map((k) => (
                    <div className="skill" key={k.id}>
                      <div><span>{k.title}</span><em>{k.level}%</em></div>
                      <i><b style={{ width: k.level + '%' }} /></i>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </section>
        )}

        {d.projects.length > 0 && (
          <section id="projects" className="sec"><h2>Projects</h2>
            <div className="cards">
              {d.projects.map((p) => (
                <a className="card" key={p.id} href={p.live_url || undefined} target="_blank" rel="noreferrer">
                  {p.image_url && <img src={p.image_url} alt="" />}
                  <h3>{p.title}</h3><p>{p.description}</p>
                  <div className="tags">{(p.tags || []).map((t) => <span key={t}>{t}</span>)}</div>
                </a>
              ))}
            </div>
          </section>
        )}

        {d.certifications.length > 0 && (
          <section id="certifications" className="sec"><h2>Certificates</h2>
            <div className="cards">
              {d.certifications.map((c) => (
                <a className="card" key={c.id} href={c.link || undefined} target="_blank" rel="noreferrer">
                  {c.image_url && <img src={c.image_url} alt="" />}
                  <h3>{c.title}</h3><p>{c.issuer}{c.issued_on ? ' · ' + c.issued_on : ''}</p>
                </a>
              ))}
            </div>
          </section>
        )}

        {d.blogs.length > 0 && (
          <section id="blogs" className="sec"><h2>Blog</h2>
            <div className="cards">
              {d.blogs.map((b) => (
                <article className="card" key={b.id}>
                  {b.cover_url && <img src={b.cover_url} alt="" />}
                  <h3>{b.title}</h3><p>{b.excerpt}</p>
                </article>
              ))}
            </div>
          </section>
        )}

        <section id="contact" className="sec"><h2>Contact</h2>
          <div className="contact">
            <div>
              <p className="lead">Kaam ya collaboration ke liye message karo.</p>
              {s.email && <p><a href={`mailto:${s.email}`}>{s.email}</a></p>}
              {s.phone && <p><a href={`tel:${s.phone}`}>{s.phone}</a></p>}
              <div className="tags">{d.profiles.map((p) => <a key={p.id} href={p.url} target="_blank" rel="noreferrer">{p.platform}</a>)}</div>
            </div>
            <form onSubmit={submit} className="panel">
              <input name="name" placeholder="Naam" required maxLength={150} />
              <input name="email" type="email" placeholder="Email" required />
              <textarea name="message" rows={5} placeholder="Message" required maxLength={4000} />
              <button className="btn">Send message</button>
              {sent && <p className="note">{sent}</p>}
            </form>
          </div>
        </section>
      </main>
      <footer>© {new Date().getFullYear()} {s.name}</footer>
    </>
  )
}
