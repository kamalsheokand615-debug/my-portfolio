# Task for the VS Code AI agent

Mere is existing portfolio project me ek **no-code admin panel** add karo. Backend Supabase me ready hai (tables, RLS, `media` storage bucket, data seeded). Is folder ki files ko use karo.

## Rules
- **Mera existing portfolio design, colors, animations aur layout bilkul same rakho.** Sirf hardcoded content ko database data se replace karo.
- Portfolio fully responsive rahe (mobile, tablet, desktop) data aane ke baad bhi. Empty sections (data nahi) hide karo.
- Naya code mere stack ke hisaab se likho (pehle package.json dekho: Vite / CRA / Next.js; JS ya TS).

## Steps
1. `npm install @supabase/supabase-js` (aur agar admin ke liye router chahiye to existing router use karo, naya mat jodo).
2. `files/src/lib/*` ko `src/lib/` me aur `files/src/admin/*` ko `src/admin/` me copy karo.
3. `files/.env.example` se `.env` banao. Variable names stack ke hisaab se badlo (Vite: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`; CRA: `REACT_APP_*`; Next: `NEXT_PUBLIC_*`) aur `src/lib/supabase.js` me wahi names use karo. Admin.jsx aur usePortfolio.js `.jsx/.js` hain, TS project me types add kar lo.
4. Route `/admin` banao jo `src/admin/Admin.jsx` render kare. Agar router nahi hai to `window.location.pathname.startsWith('/admin')` check karo. Static hosting par `/admin` refresh ke liye `files/vercel.json` copy karo (Vercel).
5. Portfolio ke sections ko `usePortfolio()` se connect karo. Ye `{ loading, settings, skills, projects, certifications, profiles, blogs }` deta hai:
   - `settings`: name, tagline, bio, photo_url, resume_url, email, phone, seo_title, seo_description, primary_color
   - `skills`: title, category, level, icon_url
   - `projects`: title, description, image_url, live_url, tags[]
   - `certifications`: title, issuer, issued_on, image_url, link
   - `profiles` (coding profiles): platform, url, username
   - `blogs`: title, excerpt, content, cover_url
6. Contact form submit par `sendMessage({ name, email, message })` (usePortfolio.js me) call karo. Success/error message dikhao.
7. SEO: `settings.seo_title` ko document title me aur `seo_description` ko meta description me lagao. `primary_color` ko existing accent CSS variable me map karo (agar accent variable hai).
8. Agar mere portfolio me koi section (jaise Experience, Testimonials) in tables me nahi hai, use waise hi rehne do aur mujhe batao.
9. `reference-design/` me ek sample portfolio hai jo sirf dikhata hai ki data kaise use hota hai. Use copy mat karo, apna design rakho.
10. `npm run dev` chalake check karo ki build error nahi hai aur `/` aur `/admin` dono khulte hain.

## Mat karna
- `supabase/schema.sql` dobara run mat karo, database pehle se ready hai.
- Admin login ke liye koi aur auth system mat banao, Supabase Auth hi use hota hai.
