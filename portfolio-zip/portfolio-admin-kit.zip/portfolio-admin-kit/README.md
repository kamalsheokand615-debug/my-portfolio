# Portfolio Admin Kit

1. Is poore folder ko VS Code me apne portfolio project ke andar rakho (ya same workspace me open karo).
2. Apne VS Code AI agent ko bolo: **"AGENT_INSTRUCTIONS.md padho aur uske hisaab se kaam karo."**
3. Supabase Dashboard > Authentication > Users > Add user (email: kamalsheokand615@gmail.com + apna password). Phir sign-ups band kar do.
4. `/admin` par isi login se sign in karo.
5. Kaam hone ke baad `portfolio-admin-kit/` folder delete kar sakte ho.
